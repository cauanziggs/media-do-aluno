package com.example.aluno

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
